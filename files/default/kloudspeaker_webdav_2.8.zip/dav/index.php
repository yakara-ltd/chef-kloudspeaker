<?php
	// NOTE! Modify these according to the location of the script
	$KLOUDSPEAKER_BACKEND_ROOT = "../";
	$BASE_URI = "/kloudspeaker/backend/dav/";
	
	$ENABLE_LOCKING = TRUE;
	$ENABLE_BROWSER = FALSE;
	$ENABLE_TEMPORARY_FILE_FILTER = TRUE;
	//$MAX_FILE_SIZE = "10M";
	
	require_once("kloudspeaker_dav.php");
?>